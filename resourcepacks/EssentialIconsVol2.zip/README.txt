INFORMATION
  This is the manual for buyers. Here will be detailed
  the information you need about the product. Thank you for buying!

  If you found a issue, contact us on discord so we can fix it.

DEPENDENCIES
  One of these plugins to manage texture packs:
    - Nexo: https://polymart.org/product/6901/nexo
    - ItemsAdder: https://builtbybit.com/resources/itemsadder.10839/
    - Oraxen: https://www.spigotmc.org/resources/oraxen.72448/

INSTALLATION
  1 - Download the product and unzip it.
  2 - Choose your desired plugin for managing texture packs
  3 - Follow the instructions to install the plugin you choose
  4 - Once the plugin is installed and the resource pack hosting is set up, copy the config files from your resource pack manager to /plugins/ folder

SUPPORT
  Discord Server: https://crystal-creations.com/discord/

DOCUMENTATION
  https://docs.crystal-creations.com/

WHICH CONFIGURATION TO CHOOSE
  To choose the configuration that suits your server, you need to follow these steps:

  1 - Go to the content folder
  2 - Choose the folder of the texture pack manager you want to use
  3 - Place the contents of the resource pack manager folder on your server in the /plugins/ folder

# 7555MG3G1NF